<template>
  <div class="AdminUser">
    <h1>{{msg}}</h1>
  </div>
</template>

<script>
export default {
  name: 'AdminUser',
  data(){
    return {
      msg:"AdminUser"
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>

</style>
