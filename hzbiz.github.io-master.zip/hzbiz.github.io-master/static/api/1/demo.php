<?php
echo mb_strlen('哈哈54353','UTF8');
$e = explode(' ', "哈哈 543 53");
print_r($e) ;
echo $_COOKIE["userid"];
?>